const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../config/empresa.json');
const { empresaNome, accessToken } = JSON.parse(fs.readFileSync(configPath, 'utf8'));

console.log('Empresa:', empresaNome);
console.log('Token Mercado Pago:', accessToken);
