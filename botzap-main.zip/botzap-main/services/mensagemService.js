const fs = require('fs');
const path = require('path');
const { carregarDados, salvarDados } = require('../utils/arquivoHelper');
const { empresaNome, planos } = require('../config/settings');
const { criarPagamentoPix, delay } = require('./pagamentoService');

const mensagensVencimento = JSON.parse(
  fs.readFileSync(path.join(__dirname, '../config/mensagens_vencimento.json'), 'utf8')
);

function verificarVencimentos() {
    const data = carregarDados();
    const hoje = new Date();

    data.clientes.forEach(cliente => {
        const expira = new Date(cliente.data_expiracao);
        const diff = Math.ceil((expira - hoje) / (1000 * 60 * 60 * 24)); // diferença em dias

        let tipo = null;
        if (diff === 7) tipo = 'antes_7';
        else if (diff === 5) tipo = 'antes_5';
        else if (diff === 3) tipo = 'antes_3';
        else if (diff === 1) tipo = 'antes_1';
        else if (diff === 0) tipo = 'no_dia';
        else if (diff === -2) tipo = 'depois_2';
        else if (diff === -3) tipo = 'depois_3';

        if (tipo) {
            const jaEnviado = data.mensagens_enviadas.find(
                msg => msg.whatsapp === cliente.whatsapp && msg.tipo === tipo
            );

            if (!jaEnviado) {
                enviarMensagem(cliente, tipo);
                data.mensagens_enviadas.push({
                    whatsapp: cliente.whatsapp,
                    tipo,
                    data_envio: hoje.toISOString().split('T')[0]
                });
            }
        }
    });

    salvarDados(data);
}
async function enviarMensagem(cliente, tipo) {
    const { client } = require('./whatsClient');
    try {
        if (!client) throw new Error('Client indefinido');

        // substitui variáveis {{empresa}} e {{nome}}
        let msgTemplate = mensagensVencimento[tipo] || "Mensagem padrão não configurada.";
        const mensagem = msgTemplate
            .replace(/{{empresa}}/g, empresaNome)
            .replace(/{{nome}}/g, cliente.nome);

        await client.sendMessage(`${cliente.whatsapp}@c.us`, mensagem);
    } catch (e) {
        console.error("Erro ao enviar mensagem:", e);
    }
}

async function lidarComMensagem(message) {
    const { client } = require('./whatsClient');
    const from = message.from;
    const body = message.body.trim();
    const valores = { '1': 17.90, '2': 88.00, '3': 135.00 };

    if (valores[body]) {
        const valor = valores[body];
        const qr = await criarPagamentoPix(from.replace('@c.us', ''), valor);
        await delay(1000);
        client.sendMessage(from, `✅ Pix de R$ ${valor} gerado!`);
        await delay(1000);
        client.sendMessage(from, `Copia e Cola:\n${qr}`);
    }
}

module.exports = { verificarVencimentos, enviarMensagem, lidarComMensagem };
